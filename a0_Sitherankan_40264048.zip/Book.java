// -----------------------------------------------------
// Assignment 0
// Question: part A
// Written by: Sitherankan Sinnappu
// -----------------------------------------------------

package lab1.comp249;

public class Book {
	String title;	
	String author;
	long ISBN;
	double price;
	static int bookNumber=0;
	
	public Book(String bookTitle, String bookAuthor, long bookISBN, double bookPrice) {
		
		title = bookTitle;
		author= bookAuthor;
		ISBN = bookISBN;
		price= bookPrice;
		bookNumber++;
		
	}
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String bookTitle) {
		bookTitle= title;
		}
	public String getAuthor() {
		return author;
	}
	
	public void setAuthor(String bookAuthor) {
		bookAuthor= author;
	}
	
	public long getISBN() {
		return ISBN;
	}
	
	public void setISBN(long bookISBN) {
		bookISBN=ISBN;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setprice(double bookPrice) {
		bookPrice = price;
	}
	
	public int findNumberOfCreatedBooks() {
		return bookNumber;	
	}
	
	public boolean equals (Book anotherBook) {
		if ((ISBN== anotherBook.ISBN) && (price==anotherBook.price)){
			System.out.println(ISBN);
			System.out.println(anotherBook.ISBN);
			return true;
		}
		else 
			return false;
			
		}
	public String toString() {
		return "The title of the book is: "+ title+" ,the author is: "+author+" , the ISBN is: "+ ISBN+" and the price is: "+price+".";	
	}	
	public static void findBooksBy (String nameAuthor,Book[] inventory) {
		for(Book b:inventory) {
			if(nameAuthor.equals(b.getAuthor())) 
				System.out.println(b);	
			}
		
	}
	
	public static void findCheaperThan (double price, Book[] inventory) {
		for(Book b: inventory) {
			if(price<b.getPrice())
				System.out.println(b);
		}
	}
}

