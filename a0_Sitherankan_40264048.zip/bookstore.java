package lab1.comp249;
import java.util.Scanner;
public class bookstore {

	public static void main(String[] args) {
		
		
		int attempt=0;
		int maxAttempt=0;
		String password= "";
		
		Scanner kb = new Scanner (System.in);
		System.out.println("Welcome to the bookstore!!!");
		System.out.print("The maximum of books that your bookstore can contain: ");
		int maxBooks = kb.nextInt();
		Book [] inventory= new Book [maxBooks];
		
		
		while(maxAttempt<4) {
		System.out.println("What do you want to do?");
		System.out.println("   1. Enter new books (password required)");
		System.out.println("   2. Change information of a book (password required)");
		System.out.println("   3. Display all books by a specific author");
		System.out.println("   4. Display all books under a certain a price.");
		System.out.println("   5. Quit");
		System.out.print("Please enter your choice >");
			int choice = kb.nextInt();
			kb.nextLine();
		 switch (choice) {
		 
		 	case 1:
		 		attempt=0;
		 		while(attempt<3) {
		 		System.out.print("Enter password:");
		 		password = kb.nextLine();
		 
		 		if(password.equals("249") ) {
		 			System.out.print("How many books do you want to enter: ");
		 			int entering = kb.nextInt();
		 			int turns = maxBooks-entering;
		 		if(turns>=0) {
		 			for (int i =0; i<=turns; i++) {
		 				System.out.print("What is the name of the  book : ");
		 				kb.nextLine();
		 				String name = kb.nextLine();
		 				System.out.print("Who is the author:");
		 				String author= kb.nextLine();
		 				System.out.print("What is the ISBN:");
		 				int ISBN = kb.nextInt();
		 				System.out.print("What is the price of the book:");
		 				int price = kb.nextInt();
		 				inventory[i]= new Book (name,author,ISBN,price);
		 				break;
		 			 }
		 			break;
		 		 }
		 		else {
		 			System.out.println("The maximum of "+maxBooks+" exceeded!");
		 			return;
		 		}
		 		
		 	 }
		 			else {
		 				System.out.println("Incorrect password. Please try again.");
		 				attempt++;
		 			
		 		if(attempt%3==0) {
		 			System.out.println("Returning to main menu due for too many attempts.");
		 			maxAttempt++;

		 					}
		 				}
		 			}
		 		break;
		 		
		 	case 2:
		 		
		 		while (attempt<3) {
		 		System.out.print("Enter passwords:");
		 		password = kb.next();
		 		attempt++;
		 		if(password.equals("249")) {
		 			System.out.print("Which number do you wishes to update:");
		 			int number=kb.nextInt()-1;
		 			if (inventory[number]==null) {
		 				System.out.println("Please re-enter another book or quit this operation:");	
		 				number=kb.nextInt()-1;
		 				break;
		 			}
		 			else {
		 				System.out.println("Book #"+number);
		 				System.out.println("Author: "+ inventory[number].getAuthor());
		 				System.out.println("Title: "+ inventory[number].getTitle());
		 				System.out.println("ISBN: "+ inventory[number].getISBN()+" #");
		 				System.out.println("Price: $"+inventory[number].getPrice());
		 				
		 				
		 				
		 				boolean work= true;
		 				while(work==true) {
		 				System.out.println("What information would you like to change?");
		 				System.out.println("1.  author");
		 				System.out.println("2.  title");
		 				System.out.println("3.  ISBN");
		 				System.out.println("4.  price");
		 				System.out.println("5.  Quit");
		 				System.out.print("Enter your choice>");
		 				int option = kb.nextInt();
		 				
		 				switch(option) {
		 				
		 				case 1:
		 					System.out.print("What name do you wanna replace the current author with:");
		 					kb.nextLine();
		 					String changeAuthor = kb.nextLine();
		 					inventory[number].setAuthor(changeAuthor);
		 					work=true;
		 					break;
		 					
		 				case 2:
		 					System.out.println("What name do you wanna replace the current title with:");
		 					kb.nextLine();
		 					String changeTitle =kb.nextLine();
		 					inventory[number].setTitle(changeTitle);
		 					work=true;
		 					break;
		 					
		 				case 3:
		 					System.out.println("What number do you wanna replace the current ISBN with:");
		 					kb.nextInt();
		 					int changeISBN= kb.nextInt();
		 					inventory[number].setISBN(changeISBN);
		 					work=true;
		 					break;
		 					
		 				case 4:
		 					System.out.println("What price do you wanna replace the current price with:");
		 					kb.nextInt();
		 					int changeCurrent =kb.nextInt();
		 					inventory[number].setprice(changeCurrent);
		 					work=true;
		 					break;
		 				
		 				case 5:
		 					work=false;
		 					break;
		 				
		 				}

		 				break;	
		 			}
		 			}
		 			 
		 			}
		 			else 
	 				System.out.println("Incorrect password. Please try again.");	
		 		}
		 		System.out.println("Returning to main menu due for too many attempts.");
	 				break;
		 		
		 		
		 		
		 	case 3:
		 		System.out.println("Enter the name of the author that you want to find: ");
		 		String nameAuthor= kb.nextLine();
		 		Book.findBooksBy(nameAuthor, inventory);
		 		break;
		 		
		 		
		 	case 4:
		 		
		 		System.out.print("What is your budget: ");
		 		int price= kb.nextInt();
		 		Book.findCheaperThan(price, inventory);
		 		break;
		 		
		 		
		 	case 5:
		 		
		 		System.out.println("Thank you for using the application!");
		 		System.out.println("Bye Bye");
		 		break;
		 		
		 	}
		}
		System.out.println("Program detected suspicous activities and will terminate immediately!");
		kb.close();
	}
}

